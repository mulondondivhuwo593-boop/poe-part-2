 GreenLeaf Lifestyle Store

 Project Overview

GreenLeaf Lifestyle Store is a multi-page website developed for a lifestyle retail business. The website provides customers with information about lifestyle, beauty, personal-care, wellness and everyday essential products.

The website is designed to provide a simple and user-friendly experience where visitors can browse products, learn more about the business, submit enquiries and access contact information.

 Website Pages

The website consists of the following pages:

* Home (`index.html`) – Introduces GreenLeaf Lifestyle Store and provides an overview of the business.
* About Us (`about.html`) – Provides information about the business, its story, mission, vision and values.
* Products (`products.html`) – Displays the available product categories and products.
* Enquiry (`enquiry.html`) – Allows visitors to submit product and general enquiries.
* Contact Us (`contact.html`) – Provides contact information and ways to communicate with GreenLeaf Lifestyle Store.

 Product Categories

The website includes the following product categories:

* Skincare
* Cosmetics
* Hair Care
* Bath & Body
* Fragrances
* Wellness
* Home Essentials
* Eco-Friendly Products

 Technologies Used

The website is currently developed using:

* HTML5
* Web browser for testing
* Visual Studio Code for development

Additional technologies such as CSS and JavaScript may be incorporated in later stages of the project.

 Project Structure

text
greenleaf lifestyle store/
│
├── index.html
├── about.html
├── products.html
├── enquiry.html
├── contact.html
│
├── assets/
│   └── OIP.jfif
│
└── .vscode/


 Features

The current website includes:

* Multi-page website structure
* Navigation between website pages
* Product categories
* Product information
* Product images
* Enquiry form
* Contact page
* Semantic HTML structure
* Alternative text for images
* Internal hyperlinks
* Footer navigation

 How to Run the Website

1. Open the project folder in Visual Studio Code.
2. Open `index.html`.
3. Save the files using Ctrl + S.
4. Open `index.html` in a web browser.
5. Use the navigation menu to move between the different pages.

 Assets

Images used on the website are stored inside the `assets` folder.

The website uses relative file paths to connect HTML pages with the required assets.

## Development Status

The HTML structure and core pages of the GreenLeaf Lifestyle Store website are currently being developed.

Future development will include improvements to:

* Website styling and layout
* Responsive design
* JavaScript functionality
* Form validation
* Search functionality
* Interactive website features
* User experience

 Project Purpose

The purpose of the project is to develop a functional and well-structured website for GreenLeaf Lifestyle Store while demonstrating appropriate web development principles and techniques.

 Author

GreenLeaf Lifestyle Store Website Project

© 2026 GreenLeaf Lifestyle Store
